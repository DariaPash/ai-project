# Учебный telecom-кейс v7

Начните с demo/telecom-v7/README-V7.md. Медиа — в submission/v7/. Это собственный анализ и медиа, не backup Store.

Код ядра и синтетический demo: https://github.com/DariaPash/ai-project/releases/tag/demo-v5
Разбор встреч v6: https://github.com/DariaPash/ai-project/releases/tag/demo-v6
