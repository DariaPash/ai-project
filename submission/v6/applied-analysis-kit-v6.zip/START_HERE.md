# Прикладной анализ v6

Начните с demo/applied-v6/README.md. MP4/PDF лежат в submission/v6/. Это собственный анализ и медиа, не полный Store backup и не отдельное приложение.

Код ядра и старый синтетический кейс: https://github.com/DariaPash/ai-project/releases/tag/demo-v5 . Новый публичный ZIP не включает vendor snapshots/receipts/credentials.
