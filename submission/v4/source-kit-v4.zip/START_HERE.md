# Исходники и собственные технические fixtures v4

См. project/README.md. Этот архив не содержит истории demo-case. Для восстановления
учебного кейса используйте local-demo-kit-v4.zip с его отдельным digest.
Технические pytest tests/ поставляются; требуются указанные macOS tools/versions.
Это не acceptance другой ОС и не benchmark. Runtime profiles/credentials не включены.
Новая публикация этих точных bytes пока не разрешена.
