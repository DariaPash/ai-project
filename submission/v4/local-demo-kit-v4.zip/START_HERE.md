# v4 — локальный кандидат, ещё не опубликован и не отправлен

Python 3.11+; локальная POSIX filesystem. macOS native import проверяется отдельно;
другие ОС и comparative benchmark не приняты. Учебные данные не доказывают спрос.

```sh
cd project
python3 -m venv .venv-run
.venv-run/bin/python -m pip install -r requirements.txt
.venv-run/bin/python -m tools.cli doctor
.venv-run/bin/python -m tools.cli import-case --case test-core --namespace test --bundle input/backups/demo.zip --trusted-bundle-sha256 b2140fc740b6fd38c62f96b8937dd1617f55a821badc3ad91f15cf9ef9873a7f
.venv-run/bin/python -m tools.cli status --case test-core
```

SHA-256 выше — явное согласие на локальную обработку принадлежащей владельцу
синтетики, а не разрешение модели/публикации и не проверка личности правообладателя.
Сверь hash с отдельно одобренным release manifest перед доверием архиву.
Исторические rights/refs/namespace не переписываются. Credentials, установленные
модели и machine capabilities отсутствуют; см. integrations/bootstrap.md.
Полезные читаемые материалы находятся в readable-case/. Исторические gate configs
не удостоверяют текущие права; doctor не выполняет live-вызовы.
Настоящее бизнес-решение остаётся awaiting_human. Новая публикация требует exact-file
approval; юридическая отправка конкурса — только капитаном.
