# Локальные исправления v4

Не full acceptance, публикация или бизнес-H.

- **A01 — addressed_local**: Independent hash-bound synthetic restore; exact history preserved (`tools/transfer.py`)
- **A02 — addressed_local**: Shipped standalone brief, tests and catalogs; clean packaged launch tested (`planning/evidence/08/run-31f4481cd91c40c4b0a94aca489858c2/clean-deliverable.json`)
- **A03 — addressed_local**: No planning bootstrap dependency; fresh MCP setup+real read succeeded. Other optional live capability acceptance remains limited (`planning/evidence/08/run-31f4481cd91c40c4b0a94aca489858c2/fresh-mcp-transport.json`)
- **A04 — deferred_owner_local_only**: GoogleDrive upload intentionally blocked by owner local-only choice (`planning/evidence/08/run-31f4481cd91c40c4b0a94aca489858c2/owner-finish-approval.json`)
- **A05 — awaiting_organizer_brief**: Owner reports supplemental brief not published; not organizer-verified official fit (`planning/evidence/06/run-17c593a124f442d6a9a43298ab851a06/correction-checkpoint-summary.json`)
- **A06 — addressed_bounded_demo**: New actual context synthesizes two proposals inside genuine recorded handoff; not proof of general cold-start research (`planning/evidence/08/run-31f4481cd91c40c4b0a94aca489858c2/live-agent-receipt.json`)
- **A07 — addressed_local**: Viewer+generator+catalog+demo inputs shipped; missing historical Codex scene fails honestly without planning (`submission/v4-candidate-05/inventory.json`)
- **A08 — addressed_local**: Complete34page PDF includes prompts, architecture, runtimes, help/time/unknowns/errors (`submission/full-story-v4/description-final.pdf`)
- **A09 — addressed_reporting**: Development versus result costs separated; unknowns stay null, new task cost settled; no invented full-result price (`planning/evidence/08/run-31f4481cd91c40c4b0a94aca489858c2/live-agent-receipt.json`)
- **A10 — addressed_local**: Russian proposals with exact citations and comparison/sensitivity; proposed, not accepted (`submission/v4-candidate-05/readable-case/manifest.json`)
- **A11 — addressed_local**: Exact-revision Russian catalog has zero translation gaps; technical originals retained (`submission/v4-candidate-05/readable-case/manifest.json`)
- **A12 — addressed_local**: Current/historical/local/public states distinguished; v3 preserved; configs described as templates/history (`README.md`)
- **A13 — addressed_local**: New CLM3/EXP4/STR4 and recorded branch STR5 distinguish actual STT from unverified quality (`submission/v4-candidate-05/readable-case/CLM-002-r3.md`)
- **A14 — addressed_local**: Promise kind included in readable documents and Codex selector corrected; old grant not rerun (`tools/continue_codex.py`)
- **A15 — addressed_local**: Implementation, runtime availability and live proof distinguished; absent/imported profiles fail closed (`tools/diagnostics.py`)
- **A16 — addressed_local**: New commits derive stage, preserve early brief_clarification and awaiting_human; old snapshots unchanged (`tools/store.py`)
- **A17 — addressed_local**: Atomic no-overwrite promotion, retained stages and read-only reconciliation after durability uncertainty (`tests/test_import_durability.py`)
- **A18 — addressed_local**: Focused captured crops,12pt body, proper Unicode font and complete text/geometry checks (`submission/full-story-v4/description-final-text-check.json`)

A04/A05 отложены по внешним условиям, не названы исправленными.
