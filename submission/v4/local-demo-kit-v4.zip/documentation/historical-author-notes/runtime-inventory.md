# Компоненты, назначение, фактические версии и границы

Это inventory авторского Mac, не обещание готовности другой машины. Версия
установленного инструмента ≠ permission ≠ успешное выполнение задачи. Read-only
версии ниже проверены локально в bounded correction; model/STT заново не запускались.
Исторические install receipts и pinned EXT подтверждают соответствующие отдельные
исполнения. Package lock — не evidence quality. Для нового окружения нужен bootstrap.

| Компонент | Наблюдаемая версия/identity | Назначение и граница |
|---|---|---|
| Python / ОС | CPython3.14.8, Darwin25.6.0 arm64 | CLI/Store/parser; другая ОС не принята |
| Локальный код `tools` | schema_version1, strategy contracts3; final source digest pending host build | Safe import/calculation/ref validation/journal; не autonomous loop |
| OpenCode | исторический server2.1.4 | Текущий OpenAI sign-in, bounded task; transient tokens/cost не сообщил |
| GPT | gpt-6.1-sol, provider identity codex в existing OpenAI | Host synthesis/review/один second-client turn; не новый provider/model |
| Codex CLI | исторический0.163.0 | Один actual continuation на том же Mac, отдельная ветка, не другая ОС |
| whisper.cpp | v1.9.5, executable SHA `0158f0e587b82440865fa2df9b75cf64000a0dbddc53c65d4b3f552c59582ac7` | Реальный local STT, EXT-017@1; listening не выполнен |
| Whisper weights | ggml-base.bin, revision `5359861c739e955e79d9a303bcbc70fb988958b1`, SHA `60ed5bc3dd14eea856493d334349b405782ddcaf0028d4b5df4088345fba2efe`,147951465bytes | Base multilingual weights; качество Russian/диаризация не принято |
| Apple Speech | OS framework; отдельная semver unknown | Ранний authorization0 отказ, не текущий whisper status |
| Apple NaturalLanguage | English sentence model revision1,512d | Настоящие embeddings, cosine/lexical/graph RRF; benchmark качества не проведён |
| Swift |6.3.3 (`swiftlang-6.3.3.1.3 clang-2100.1.1.101`) | Apple adapters и исторический media renderer; macOS-bound |
| filesystem MCP server | официальный @modelcontextprotocol/server-filesystem2.3.0 | initialize/list/read_text_file на dedicated root; клиент запрещает write/delete |
| MCP Python SDK |2.3.0 | stdio MCP transport/schema/catalog; реальный read/import ≠ product export |
| Node / npm |v26.8.2 /11.19.1 | Локальный запуск pinned MCP server; runtime executable новой машины надо найти |
| Tesseract |5.5.3 | OCR text/confidence/bbox; raw uncertainty сохраняется |
| Poppler / pdftoppm |26.09.0 | Рендер scan-PDF страниц для OCR; не semantic interpretation |
| FFmpeg / ffprobe |9.0.2 /9.0.2 | Media extraction/frame timestamps/encode/metadata; не понимание видео |
| CMake |4.4.5 | Историческая локальная сборка whisper, не runtime модели |
| jsonschema |4.26.0 | Schema validation, не проверка истинности/полезности |
| pypdf |7.1.0 | Извлечение text-PDF; не OCR и не финальная вёрстка |
| openpyxl / et_xmlfile |3.1.5 /2.0.0 (второй из requirements lock) | XLSX/cell extraction; не macros/external links, formulas не вычисляются |
| beautifulsoup4 / soupsieve |4.15.0 /4.1 (второй из lock) | HTML snapshot parsing, не live browser/JS/fetch permission |
| pytest |9.2.0 | Разрешённые technical regression checks; не benchmark и не full acceptance |
| reportlab | Не установлен в .venv-dev при проверке | Не используется этим worker; PDF renderer host выберет/проверит отдельно |
| Apple media/PDF renderer | Финальная v4 версия/настройки unknown | Не считать Markdown уже готовым PDF; actual page rendering ещё pending |
| GitHub | Историческая публикация exact v3 assets | Не новый upload/approval v4; сеть этим worker не использовалась |
| Google Drive | Выбран, не connected/uploaded | Anonymous playback и точный upload scope ещё не проверены |

Поддерживающие pinned зависимости `requirements.txt`: attrs26.1.0,
iniconfig2.3.1, jsonschema-specifications2025.9.1, packaging26.3, pluggy1.7.0,
Pygments2.21.0, referencing0.37.0, rpds-py2026.9.1, setuptools84.2.1,
typing_extensions4.16.0. Это **declared lock**, не отдельные capability receipts:
validation registry, packaging, test/config и formatting инфраструктура.
Отдельные версии stdlib Decimal/JSON/hashlib/fcntl не назначаются — Python3.14.8.

Финальная source archive version/digest, bootstrap clean install, safe locks на
другой ОС, полный runtime smoke и full F01–F15 acceptance остаются host integration.
Наличие таблицы не снимает этих ограничений.
