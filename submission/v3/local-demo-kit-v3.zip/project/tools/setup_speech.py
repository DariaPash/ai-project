"""Owner-approved project-local whisper.cpp installation, never a test runner."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import urllib.request

from .development import ROOT, now, write_json


def main():
    progress = json.loads((ROOT / "planning/progress.json").read_text())
    evidence = ROOT / progress["active_run"]
    approval = json.loads((evidence / "resource-approval-receipt.json").read_text())
    if approval["status"] != "approved_by_owner_message":
        raise SystemExit("Project installation requires explicit owner approval")
    version = json.loads((evidence / "whisper_release-metadata.json").read_text())["tag_name"]
    cmake_version = json.loads((evidence / "cmake-metadata.json").read_text())["info"]["version"]
    base = ROOT / ".local/integrations"
    base.mkdir(parents=True, exist_ok=True)
    receipt = evidence / "speech-install-receipt.json"
    if receipt.exists():
        raise SystemExit("Installation receipt exists; inspect it before any repeated install")
    report = {
        "at": now(),
        "actual": True,
        "status": "started",
        "whisper_version": version,
        "cmake_version": cmake_version,
        "downloads": [],
        "commands": [],
        "tests_run": False,
    }
    write_json(receipt, report)

    def save():
        write_json(receipt, report)

    def command(args, name, timeout):
        log = evidence / (name + ".log")
        with log.open("xb") as stream:
            result = subprocess.run(
                args,
                cwd=ROOT,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=timeout,
                env={**os.environ, "PIP_DISABLE_PIP_VERSION_CHECK": "1"},
            )
        report["commands"].append({"name": name, "exit": result.returncode, "log": str(log.relative_to(ROOT))})
        save()
        if result.returncode:
            raise RuntimeError(name + " failed; inspect preserved log, do not retry automatically")

    def download(url, path, cap):
        if path.exists():
            raise RuntimeError("Existing download must be reconciled before reuse: " + path.name)
        size = 0
        digest = hashlib.sha256()
        with (
            urllib.request.urlopen(
                urllib.request.Request(url, headers={"User-Agent": "ai-project-local-setup"}), timeout=60
            ) as response,
            path.open("xb") as output,
        ):
            while True:
                block = response.read(65536)
                if not block:
                    break
                size += len(block)
                if size > cap:
                    raise RuntimeError("Approved download byte cap exceeded")
                output.write(block)
                digest.update(block)
        report["downloads"].append(
            {"url": url, "path": str(path.relative_to(ROOT)), "bytes": size, "sha256": digest.hexdigest()}
        )
        save()

    try:
        command(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--index-url",
                "https://pypi.org/simple",
                "--only-binary=:all:",
                "--report",
                str(evidence / "cmake-pip-report.json"),
                "cmake==" + cmake_version,
            ],
            "cmake-install",
            180,
        )
        tarball = base / ("whisper.cpp-" + version + ".tar.gz")
        download(
            "https://codeload.github.com/ggml-org/whisper.cpp/tar.gz/refs/tags/" + version, tarball, 64 * 1024 * 1024
        )
        stage = base / ("whisper.cpp-" + version)
        stage.mkdir(exist_ok=False)
        with tarfile.open(tarball) as archive:
            members = archive.getmembers()
            if len(members) > 20000 or sum(m.size for m in members) > 256 * 1024 * 1024:
                raise RuntimeError("Source archive exceeds install cap")
            archive.extractall(stage, filter="data")
        roots = [p for p in stage.iterdir() if p.is_dir()]
        if len(roots) != 1:
            raise RuntimeError("Unexpected source layout")
        source = roots[0]
        build = stage / "build"
        cmake = str(ROOT / ".venv-dev/bin/cmake")
        command(
            [
                cmake,
                "-S",
                str(source),
                "-B",
                str(build),
                "-DCMAKE_BUILD_TYPE=Release",
                "-DWHISPER_BUILD_TESTS=OFF",
                "-DWHISPER_BUILD_EXAMPLES=ON",
                "-DGGML_METAL=OFF",
                "-DGGML_OPENMP=OFF",
            ],
            "speech-configure",
            120,
        )
        command([cmake, "--build", str(build), "--target", "whisper-cli", "-j", "4"], "speech-build", 600)
        with urllib.request.urlopen("https://huggingface.co/api/models/ggerganov/whisper.cpp", timeout=30) as response:
            metadata = json.load(response)
        revision = metadata["sha"]
        models = ROOT / ".local/models"
        models.mkdir(exist_ok=True)
        model = models / "ggml-base.bin"
        download(
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/" + revision + "/ggml-base.bin",
            model,
            200 * 1024 * 1024,
        )
        executable = build / "bin/whisper-cli"
        executable_hash = hashlib.sha256(executable.read_bytes()).hexdigest()
        runtime = {
            "schema_version": 1,
            "engine": "whisper.cpp",
            "version": version,
            "executable": str(executable.relative_to(ROOT)),
            "executable_sha256": executable_hash,
            "model": str(model.relative_to(ROOT)),
            "model_sha256": hashlib.sha256(model.read_bytes()).hexdigest(),
            "model_id": "ggerganov/whisper.cpp/ggml-base.bin",
            "model_revision": revision,
            "network_during_recognition": False,
            "languages": ["eng", "rus"],
            "approval_receipt": str((evidence / "resource-approval-receipt.json").relative_to(ROOT)),
        }
        write_json(ROOT / ".local/speech-runtime.json", runtime)
        report.update(status="installed_not_transcription_verified", ended_at=now(), runtime=runtime)
        save()
        print(
            json.dumps(
                {
                    "status": report["status"],
                    "version": version,
                    "model_bytes": model.stat().st_size,
                    "runtime": ".local/speech-runtime.json",
                    "tests_run": False,
                }
            )
        )
    except Exception as error:
        report.update(status="failed", ended_at=now(), error_type=type(error).__name__, error=str(error))
        save()
        raise


if __name__ == "__main__":
    main()
