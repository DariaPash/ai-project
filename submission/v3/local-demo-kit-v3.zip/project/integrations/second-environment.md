# Перенос во вторую среду

Новый isolated context текущего harness — новая сессия N, не другая среда E.
Другая папка/venv также не E. Автоматический запуск второго реального IDE-клиента
не установлен и не заявляется. Capabilities/credentials первой машины не переносятся.

`export --mode backup` создаёт local snapshot/history/archive с hashes. Если sources
не имеют external_transfer rights, архив local-only и import в другую root запрещён.
`public` требует publication rights всех sources; restricted corpus не удаляется
тихо под видом полностью воспроизводимого архива. Для передачи нужны scoped права.
Import не выполняет код ZIP, не перенумеровывает refs и не меняет namespace.
