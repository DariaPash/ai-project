# OpenAI: через существующую подписку OpenCode, не через новый API key

Владелец разрешил текущий OpenAI-провайдер OpenCode и лимит$100 по самостоятельно
считаемому API-эквиваленту токенов. Настоящий вызов уже выполнен через
`tools/adapters/opencode_model.py`: отдельная host session, сохранённый raw response,
RTE-002 и reconciliation без повторной генерации. Подробности — `host.md`.

Официальные rates gpt-6.1-sol прочитаны со страницы OpenAI API pricing. Для budget
guard используются более высокие long-context rates и reasoning over-count,
дополнительные неизвестные расходы резервируются, не считаются нулевыми.
Расход ChatGPT quota нельзя достоверно вывести из этих rates; OAuth credentials
не извлекаются. Actual transient tokens сервер не сообщил — полный$10 reserve удержан.

## Отдельный API-key adapter

Для отдельного вызова api.openai.com по API key нет отдельного согласованного
credential/endpoint scope. Он не нужен для уже работающего OpenCode-пути.
Ключи не читались, запросы/платежи не выполнялись. module model_openai возвращает
MODEL_API_BLOCKED — это **не реализованный API adapter и не live capability**.
Работающий разрешённый путь отдельного review — host bridge. API adapter можно
реализовывать после доступной актуальной спецификации и scoped разрешения;
не подставлять выдуманный response/model ID или цену.
