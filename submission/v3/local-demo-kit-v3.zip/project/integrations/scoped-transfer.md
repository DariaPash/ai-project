# Перенос собственного учебного кейса с отдельным согласием

Исторические `source.rights.external_transfer=false` не переписываются.
Дополнительное real APR scope=data_transfer связывает exact source revisions/hashes,
неизменяемое предложение, человеческий ответ и точный destination root.
Это право локального копирования истории; в Codex разрешён только обезличенный
синтетический текст, не raw audio/video. Публикация и business-H не разрешаются.

```sh
python -m tools.cli export --case test-core --mode backup --out output/backups/codex-v1.zip --approval APR-ID --destination /absolute/local/project
python -m tools.cli import-case --case test-core --namespace test --bundle input/backups/codex-v1.zip --authorization-project /absolute/original/project --approval APR-ID
```

Import запускается в destination root. Original project указывается явно как
доверенный локальный источник: проверяются committed APR, source inventory и
неизменяемый export receipt вне ZIP, связывающий архив, snapshot и destination.
Редактируемый manifest ZIP не может сам разрешить передачу. Архив сначала
проверяется в staging; namespace/refs/history сохраняются, overwrite запрещён.
Capabilities, credentials, environments и locks не переносятся. Это не универсальная
подписанная межмашинная авторизация: пока исходный trusted local Store недоступен,
такой restricted import остаётся blocked.

Без этих флагов сохраняется прежний same-root backup receipt path. Public export
всегда отдельно требует publication rights на все источники.
