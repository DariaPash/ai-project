# Исправленный комплект v5

Это папка IDE-агента, не автономное приложение. Все данные поставляемого примера
синтетические. Реальные спрос, бизнес-эффект, baseline и согласие не установлены.

В `project/` — текущие исходники, инструкции, тесты и читаемые результаты.
`project/docs/DEMO-SUMMARY.md` — актуальное исправленное пояснение;
`project/docs/REVIEW-FOLLOWUP.md` — результат проверки каждого пункта ревью.
README содержит ссылки на GitHub-медиа; в source-kit часть release-only материалов
может быть доступна только по внешним ссылкам. Полный комплект включает media/.

## 1. Установить локальное ядро

Откройте терминал **в `project/`**. Проверенная среда: CPython3.14.8/macOS arm64,
локальная POSIX filesystem. Не переиспользуйте пользовательскую `.venv`.
Создавайте окружение только если его ещё нет. Установка требует разрешённой сети.

```sh
python3 -m venv .venv-dev
.venv-dev/bin/python -m pip install -r requirements.txt
.venv-dev/bin/python -m pip install --no-build-isolation -e .
.venv-dev/bin/python -m tools.cli doctor
```

Doctor не скачивает пакеты и не делает модельных вызовов. Интеграции и подписка
автора не наследуются; опциональный bootstrap — `integrations/bootstrap.md`.

## 2. Восстановить пример (только полный комплект)

Вложенный `input/backups/demo.zip` — исходный checkpoint173 v4. Сохранена история,
а исправленные пояснения v5 лежат отдельно. Доверенный **вне ZIP** SHA-256:

```text
b2140fc740b6fd38c62f96b8937dd1617f55a821badc3ad91f15cf9ef9873a7f
```

```sh
.venv-dev/bin/python -m tools.cli import-case --case test-core --namespace test --bundle input/backups/demo.zip --trusted-bundle-sha256 b2140fc740b6fd38c62f96b8937dd1617f55a821badc3ad91f15cf9ef9873a7f
.venv-dev/bin/python -m tools.cli status --case test-core
.venv-dev/bin/python -m tools.cli validate --case test-core
.venv-dev/bin/python helpers/review-demo-v5.py options
.venv-dev/bin/python helpers/review-demo-v5.py decision
```

Не повторяйте import поверх существующего кейса. Digest разрешает только локальную
обработку собственной точной синтетики, не модельные вызовы, передачу или публикацию.
В source-kit без backup начните с `init --case test-quickstart --namespace test`.

## 3. Продолжить с IDE-агентом

Откройте `project/` в IDE. Попросите прочитать AGENTS, status/handoff, бриф и
исправленную сводку. Неизвестный горизонт, бюджет, ответственный и реальное H не
заполняются автоматически. «Остановись» — checkpoint; «продолжи» — новый status;
«измени ограничение» — адресный impact и новое согласование, если меняется решение.

Тесты: `.venv-dev/bin/python -m pytest -q` из `project/`. Они не требуют
внутреннего planning/ и не являются сравнительным benchmark.
Результаты сборки — checks.json рядом с release manifest на GitHub.

V4 содержал ошибочную арифметику и ложную смену лидера. В v5 правильное значение
improve при0,5/0,3/0,2 —3,5; лидер в трёх показанных сценариях не меняется.
Новая PTY-запись показывает чтение сохранённого кейса и исправления, **не новую
модельную генерацию**. Юридическая отправка и внешний видеохост не выполнены.
